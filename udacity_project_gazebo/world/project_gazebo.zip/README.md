# README FIRST
## Notice
In order to realize printing "Welcome to Jason's World", 
- you need to export the /build path to GAZEBO_PLUGIN_PATH at first.
- use "gazebo world --verbose" to the print information.

## Info
1. /model containts the robot and wall model.
2. /script contains the script.cpp file for gazebo plugin.
3. /world contains the gazebo world file, with robot and wall mode in it.